# ZEEFX VOTEX ENHANCER V7.7 — Android + Online Server

## ምን አለ?
- Native Android app (Kotlin), red/black ZEEFX branding
- Pick image/video from phone
- 1x / 2x scaling
- Denoise, detail/contrast and sharpening sliders
- Upload to your own HTTPS processing server
- Download processed image/video
- FastAPI/OpenCV server source (not Hugging Face)

## Important limitation
This starter project uses OpenCV enhancement (resize, denoise, local contrast and sharpen). It is **not** a trained AI model like Proteus/Topaz. To get AI upscaling, you must integrate a model supported by your server hardware. Large video files require a server with enough RAM, disk space and processing capacity.

## A. Set up the online server
Use a Linux VPS or another Python hosting service where you can run a persistent FastAPI app. Hugging Face is not used.

1. Copy the `server/` folder to your server.
2. Install Python 3.10+ and FFmpeg.
3. In the server folder run:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn main:app --host 0.0.0.0 --port 8000
   ```
4. Put it behind HTTPS using a domain and reverse proxy (for example Caddy or Nginx + TLS). Do not send private media to an untrusted public server.
5. Test `https://YOUR-DOMAIN/health`.

For a public deployment, add authentication, upload size limits, rate limits, cleanup policy, and a firewall before sharing the server.

## B. Connect the Android app
Open `android/` in Android Studio. Edit:
`app/src/main/java/com/zeefx/votex/Config.kt`

Set `API_BASE_URL` to the server origin, including `https://`, and no trailing slash. Example:
`https://votex.example.com`

Do not use `localhost` in the APK: on the phone it means the phone itself, not your remote server.

## C. Build APK
1. Install Android Studio on a computer and let it install Android SDK.
2. Open the `android/` folder.
3. Wait for Gradle sync.
4. Choose **Build > Build APK(s)**.
5. Find the debug APK in `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

This archive contains project source, not a prebuilt APK. An Android SDK/Gradle build environment is needed to compile the APK.

## API
`POST /process` multipart fields:
- `file`: image/video
- `scale`: `1` or `2`
- `denoise`, `detail`, `sharpen`: numbers 0–100

The server returns the processed file as a download response.
