plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zeefx.votex"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zeefx.votex"
        minSdk = 29
        targetSdk = 35
        versionCode = 77
        versionName = "7.7"
    }
}
