package com.zeefx.votex

object Config {
    // Set this to your own HTTPS server origin. No trailing slash.
    // Example: https://votex.example.com
    const val API_BASE_URL = "https://YOUR-SERVER-DOMAIN"
    const val PROCESS_PATH = "/process"
}
