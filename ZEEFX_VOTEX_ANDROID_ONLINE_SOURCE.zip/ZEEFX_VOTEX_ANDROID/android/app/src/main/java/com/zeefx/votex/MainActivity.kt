package com.zeefx.votex

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.content.ContentValues
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val red = Color.rgb(255, 77, 77)
    private val bg = Color.rgb(10, 0, 0)
    private val panel = Color.rgb(25, 5, 5)
    private var pickedUri: Uri? = null
    private var pickedName = "upload"
    private var pickedMime = "application/octet-stream"
    private lateinit var selectedFile: TextView
    private lateinit var status: TextView
    private lateinit var scaleSpinner: Spinner
    private lateinit var denoise: SeekBar
    private lateinit var detail: SeekBar
    private lateinit var sharpen: SeekBar
    private lateinit var processButton: Button
    private lateinit var chooseButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val crab = label("🦀", 36f, red, true)
        crab.gravity = Gravity.CENTER
        root.addView(crab, matchWrap())

        val title = label("VOTEX", 30f, red, true).apply { gravity = Gravity.CENTER }
        root.addView(title, matchWrap())
        val subtitle = label("ENHANCER · V7.7", 12f, Color.LTGRAY, true).apply {
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())
        val brand = label("ZEEFX PROJECT · MADE BY ZEEFX", 11f, Color.GRAY, false).apply {
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())
        root.addView(space(18))

        selectedFile = label("No file selected", 14f, Color.WHITE, false)
        selectedFile.setPadding(dp(12), dp(12), dp(12), dp(12))
        selectedFile.setBackgroundColor(panel)
        root.addView(selectedFile, matchWidth())

        chooseButton = button("📁  CHOOSE IMAGE / VIDEO")
        root.addView(chooseButton, matchWidth())
        chooseButton.setOnClickListener { chooseFile() }

        root.addView(label("OUTPUT SCALE", 13f, red, true), matchWrap())
        scaleSpinner = Spinner(this)
        val scaleAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("2x", "1x"))
        scaleSpinner.adapter = scaleAdapter
        root.addView(scaleSpinner, matchWidth())

        root.addView(label("NOISE REDUCTION", 13f, red, true), matchWrap())
        denoise = slider(20)
        root.addView(denoise, matchWidth())
        root.addView(label("DETAIL / LOCAL CONTRAST", 13f, red, true), matchWrap())
        detail = slider(35)
        root.addView(detail, matchWidth())
        root.addView(label("SHARPEN", 13f, red, true), matchWrap())
        sharpen = slider(25)
        root.addView(sharpen, matchWidth())

        processButton = button("▶  PROCESS · ZEEFX")
        root.addView(processButton, matchWidth())
        processButton.setOnClickListener { startProcessing() }

        status = label("Ready. Choose a file to begin.", 13f, Color.WHITE, false)
        status.setPadding(dp(10), dp(14), dp(10), dp(14))
        root.addView(status, matchWidth())

        val note = label(
            "Online processing requires your own HTTPS server. This starter server uses OpenCV enhancement, not a trained Topaz/Proteus AI model.",
            11f, Color.LTGRAY, false
        )
        note.setPadding(dp(4), dp(10), dp(4), dp(4))
        root.addView(note, matchWidth())
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
        }
        startActivityForResult(intent, 701)
    }

    @Deprecated("Use document picker result for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 701 || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        pickedUri = uri
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        pickedName = queryName(uri) ?: "votex_upload"
        pickedMime = contentResolver.getType(uri) ?: ""
        selectedFile.text = "Selected: $pickedName"
        status.text = "File ready. Press PROCESS."
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun startProcessing() {
        val uri = pickedUri
        if (uri == null) {
            status.text = "Please choose an image or video first."
            return
        }
        if (Config.API_BASE_URL.contains("YOUR-SERVER-DOMAIN")) {
            status.text = "Setup required: edit Config.kt and set your HTTPS server URL."
            return
        }
        processButton.isEnabled = false
        chooseButton.isEnabled = false
        status.text = "Uploading file… keep the app open."
        thread {
            try {
                val result = uploadAndProcess(uri)
                runOnUiThread {
                    processButton.isEnabled = true
                    chooseButton.isEnabled = true
                    status.text = "✓ Saved to Downloads: $result"
                    Toast.makeText(this, "Output saved: $result", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    processButton.isEnabled = true
                    chooseButton.isEnabled = true
                    status.text = "Error: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }
    }

    private fun uploadAndProcess(uri: Uri): String {
        val boundary = "----ZEEFX${UUID.randomUUID()}"
        val endpoint = URL(Config.API_BASE_URL.trimEnd('/') + Config.PROCESS_PATH)
        val conn = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 10 * 60 * 1000
            doOutput = true
            useCaches = false
            setChunkedStreamingMode(64 * 1024)
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/octet-stream")
        }

        val scale = if (scaleSpinner.selectedItem.toString() == "2x") "2" else "1"
        val fields = mapOf(
            "scale" to scale,
            "denoise" to denoise.progress.toString(),
            "detail" to detail.progress.toString(),
            "sharpen" to sharpen.progress.toString()
        )

        conn.outputStream.use { raw ->
            BufferedOutputStream(raw).use { out ->
                for ((key, value) in fields) {
                    out.write("--$boundary\r\n".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"$key\"\r\n\r\n".toByteArray())
                    out.write(value.toByteArray())
                    out.write("\r\n".toByteArray())
                }
                val safeName = pickedName.replace("\"", "").replace("\r", "").replace("\n", "")
                out.write("--$boundary\r\n".toByteArray())
                out.write("Content-Disposition: form-data; name=\"file\"; filename=\"$safeName\"\r\n".toByteArray())
                out.write("Content-Type: ${pickedMime.ifBlank { "application/octet-stream" }}\r\n\r\n".toByteArray())
                contentResolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        out.write(buffer, 0, n)
                    }
                } ?: throw IllegalStateException("Could not read selected file")
                out.write("\r\n--$boundary--\r\n".toByteArray())
                out.flush()
            }
        }

        val code = conn.responseCode
        if (code !in 200..299) {
            val errorText = try {
                conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
            } catch (_: Exception) { "HTTP $code" }
            conn.disconnect()
            throw IllegalStateException("Server returned HTTP $code: ${errorText.take(250)}")
        }

        val isVideo = pickedMime.startsWith("video/") ||
            pickedName.substringAfterLast('.', "").lowercase() in
            listOf("mp4", "mov", "mkv", "avi", "webm", "m4v")
        val ext = if (isVideo) "mp4" else "png"
        val mime = if (isVideo) "video/mp4" else "image/png"
        val outName = "zeefx_votex_${System.currentTimeMillis()}.$ext"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ZEEFX")
        }
        val outputUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create output file in Downloads")
        try {
            contentResolver.openOutputStream(outputUri)?.use { target ->
                BufferedInputStream(conn.inputStream).use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        target.write(buffer, 0, n)
                    }
                }
            } ?: throw IllegalStateException("Could not save output")
        } catch (e: Exception) {
            contentResolver.delete(outputUri, null, null)
            throw e
        } finally {
            conn.disconnect()
        }
        return outName
    }

    private fun slider(value: Int): SeekBar = SeekBar(this).apply {
        max = 100
        progress = value
        progressTintList = android.content.res.ColorStateList.valueOf(red)
        thumbTintList = android.content.res.ColorStateList.valueOf(red)
    }

    private fun button(text: String): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(139, 0, 0))
        textSize = 14f
        isAllCaps = false
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
