import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import cv2
import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

app = FastAPI(title="ZEEFX VOTEX Processing API", version="7.7")

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "250"))
ALLOWED_IMAGES = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
ALLOWED_VIDEOS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}
ROOT = Path(os.getenv("VOTEX_WORKDIR", tempfile.gettempdir()))

def cleanup_dir(path: str):
    shutil.rmtree(path, ignore_errors=True)

@app.get("/health")
def health():
    return {"ok": True, "service": "ZEEFX VOTEX", "version": "7.7",
            "mode": "OpenCV fallback (not trained AI)"}

def enhance(frame, scale, denoise, detail, sharpen):
    h, w = frame.shape[:2]
    if scale == 2:
        frame = cv2.resize(frame, (w * 2, h * 2), interpolation=cv2.INTER_LANCZOS4)
    if denoise > 0:
        strength = max(1, min(10, round(denoise / 10)))
        frame = cv2.fastNlMeansDenoisingColored(frame, None, strength, strength, 7, 21)
    if detail > 0:
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=1.0 + detail / 100.0 * 1.5,
                                tileGridSize=(8, 8))
        l = clahe.apply(l)
        frame = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)
    if sharpen > 0:
        amount = sharpen / 100.0
        blurred = cv2.GaussianBlur(frame, (0, 0), 1.0)
        frame = cv2.addWeighted(frame, 1.0 + amount, blurred, -amount, 0)
    return np.clip(frame, 0, 255).astype(np.uint8)

def process_image(src: Path, out: Path, scale, denoise, detail, sharpen):
    img = cv2.imread(str(src), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError("Could not decode image")
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif img.ndim == 3 and img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
    elif img.ndim != 3 or img.shape[2] != 3:
        raise ValueError("Unsupported image format")
    result = enhance(img, scale, denoise, detail, sharpen)
    if not cv2.imwrite(str(out), result):
        raise RuntimeError("Could not write output image")

def process_video(src: Path, out: Path, work: Path, scale, denoise, detail, sharpen):
    cap = cv2.VideoCapture(str(src))
    if not cap.isOpened():
        raise ValueError("Could not open video")
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 0 or fps > 240:
        fps = 25.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if w <= 0 or h <= 0:
        cap.release()
        raise ValueError("Invalid video dimensions")

    silent = work / "silent.mp4"
    writer = cv2.VideoWriter(str(silent), cv2.VideoWriter_fourcc(*"mp4v"),
                             fps, (w * scale, h * scale))
    if not writer.isOpened():
        cap.release()
        raise RuntimeError("Could not create video output")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            writer.write(enhance(frame, scale, denoise, detail, sharpen))
    finally:
        cap.release()
        writer.release()

    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        shutil.copy2(silent, out)
        return
    # Preserve original audio where available. Fall back to silent output if needed.
    cmd = [
        ffmpeg, "-y", "-i", str(silent), "-i", str(src),
        "-map", "0:v:0", "-map", "1:a:0?", "-c:v", "libx264",
        "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "160k", "-shortest", str(out)
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3600)
    if result.returncode != 0 or not out.exists() or out.stat().st_size == 0:
        cmd = [ffmpeg, "-y", "-i", str(silent), "-c:v", "libx264",
               "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", str(out)]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3600)
        if result.returncode != 0:
            raise RuntimeError("FFmpeg encoding failed")

@app.post("/process")
async def process(
    file: UploadFile = File(...),
    scale: int = Form(2),
    denoise: int = Form(20),
    detail: int = Form(35),
    sharpen: int = Form(25),
):
    if scale not in (1, 2):
        raise HTTPException(400, "scale must be 1 or 2")
    if any(v < 0 or v > 100 for v in (denoise, detail, sharpen)):
        raise HTTPException(400, "sliders must be in the 0–100 range")

    filename = Path(file.filename or "upload.bin").name
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_IMAGES | ALLOWED_VIDEOS:
        raise HTTPException(415, "Unsupported file type")
    work = Path(tempfile.mkdtemp(prefix="zeefx_votex_"))
    src = work / ("input" + ext)
    is_image = ext in ALLOWED_IMAGES
    out = work / ("zeefx_votex_output.png" if is_image else "zeefx_votex_output.mp4")

    size = 0
    try:
        with src.open("wb") as dest:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    raise HTTPException(413, f"Upload exceeds {MAX_UPLOAD_MB} MB limit")
                dest.write(chunk)
        await file.close()

        try:
            if is_image:
                process_image(src, out, scale, denoise, detail, sharpen)
            else:
                process_video(src, out, work, scale, denoise, detail, sharpen)
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(422, f"Processing failed: {type(exc).__name__}: {exc}")

        return FileResponse(
            str(out),
            media_type="image/png" if is_image else "video/mp4",
            filename=out.name,
            background=BackgroundTask(cleanup_dir, str(work)),
        )
    except Exception:
        # FileResponse owns cleanup on success; clean up failures here.
        if work.exists():
            cleanup_dir(str(work))
        raise
